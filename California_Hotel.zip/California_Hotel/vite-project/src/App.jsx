import React from "react";
import Header from "./commopents/Header/Header";

function App() {
  return (
    <div className="wrapper">
      <Header />
    </div>
  );
}

export default App;
